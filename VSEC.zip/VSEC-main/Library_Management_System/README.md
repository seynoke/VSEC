# Libra — Library Management System

A college mini project built using **HTML, CSS, frontend JavaScript, Node.js, Express.js, REST API and JSON-file storage**. It does not use MySQL, MongoDB, or any other database server.

## Features

- Professional responsive dashboard and sidebar navigation
- Dashboard summary: total book copies, registered members, currently issued books, overdue books
- **Books CRUD:** add, list, search, edit, and delete books
- **Members CRUD:** register, list, search, edit, and delete members
- Issue books to members and mark them returned
- Availability tracking and overdue status
- Search by book title, author, ISBN, category, member details, or loan details
- Validation for required fields, duplicate ISBN/email, stock quantity, and available copies
- Data persists in local JSON files between server restarts
- Mobile-friendly layout and success/error messages

## Technology stack

| Layer | Technology |
|---|---|
| Frontend | HTML5, CSS3, JavaScript |
| Backend | Node.js |
| Server framework | Express.js |
| Communication | REST API using JSON |
| Storage | `data/books.json`, `data/members.json`, `data/loans.json` |
| Database server | Not used |

## Requirements

- Node.js (LTS recommended)
- npm (included with Node.js)
- VS Code or any code editor
- A modern web browser

## Setup and run

1. Download and extract the project ZIP.
2. Open the `Library_Management_System` folder in VS Code.
3. Open the terminal in that folder.
4. Install the Express dependency:

   ```bash
   npm install
   ```

5. Start the server:

   ```bash
   npm start
   ```

6. Open **http://localhost:5000** in your browser.

To stop the server, press `Ctrl + C` in the terminal. Start it again with `npm start`.

## Project structure

```text
Library_Management_System/
├── data/
│   ├── books.json
│   ├── members.json
│   └── loans.json
├── public/
│   ├── index.html
│   ├── styles.css
│   └── app.js
├── .gitignore
├── package.json
├── server.js
└── README.md
```

## How to demonstrate

1. Open Dashboard and show the summary cards.
2. Go to **Book collection** and add a book.
3. Search for the book, edit its details, then show its delete action (do not delete it if you need it for the next step).
4. Go to **Members** and register a member.
5. Go to **Issue & returns**, issue an available book to that member and set a due date.
6. Show the issued count and the book's reduced availability.
7. Mark the book as returned and show the status change.
8. Restart the server and show that records remain because they are saved in JSON files.

## REST API endpoints

### Dashboard
- `GET /api/dashboard` — summary counts
- `GET /api/health` — API and storage status

### Books
- `GET /api/books?q=search-term` — list/search books
- `POST /api/books` — add a book
- `PUT /api/books/:id` — edit a book
- `DELETE /api/books/:id` — delete a book

Example book JSON:
```json
{
  "title": "The Alchemist",
  "author": "Paulo Coelho",
  "isbn": "9780061122415",
  "category": "Fiction",
  "quantity": 3,
  "shelf": "A-03"
}
```

### Members
- `GET /api/members?q=search-term` — list/search members
- `POST /api/members` — register a member
- `PUT /api/members/:id` — edit a member
- `DELETE /api/members/:id` — delete a member

Example member JSON:
```json
{
  "name": "Aarav Patil",
  "email": "aarav@example.com",
  "phone": "9876543210",
  "course": "IT Engineering"
}
```

### Issue & returns
- `GET /api/loans?q=search-term` — list/search issue records
- `POST /api/loans` — issue a book
- `PATCH /api/loans/:id/return` — mark an issued book as returned

Example issue JSON:
```json
{
  "bookId": 1,
  "memberId": 1,
  "dueDate": "2026-11-10"
}
```

## Data model

- **Book:** `id`, `title`, `author`, `isbn`, `category`, `quantity`, `shelf`, timestamps
- **Member:** `id`, `memberCode`, `name`, `email`, `phone`, `course`, timestamps
- **Loan:** `id`, `bookId`, `memberId`, `issueDate`, `dueDate`, `returnDate`, `status`

## Important notes

- This is a mini-project/demo intended for local use, not a production multi-user library system.
- JSON files are suitable for a small demo. They do not provide database transactions or robust concurrent-write protection.
- There is no login/authentication, fines/payment system, email/SMS notification, or cloud sync.
- Keep a backup copy of the `data` folder if your project records are important.
- Do not delete a book with active issues or a member who currently has an issued book; the API blocks these actions.
