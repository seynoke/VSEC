const express = require('express');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 5000;
const DATA_DIR = path.join(__dirname, 'data');

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

function ensureFile(fileName, initialData = []) {
  const filePath = path.join(DATA_DIR, fileName);
  if (!fs.existsSync(filePath)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    fs.writeFileSync(filePath, JSON.stringify(initialData, null, 2));
  }
  return filePath;
}

const booksFile = ensureFile('books.json');
const membersFile = ensureFile('members.json');
const loansFile = ensureFile('loans.json');

function readData(file) {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch (error) {
    console.error(`Could not read ${path.basename(file)}:`, error.message);
    return [];
  }
}
function writeData(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}
function nextId(items) {
  return items.reduce((max, item) => Math.max(max, Number(item.id) || 0), 0) + 1;
}
function cleanString(value) {
  return typeof value === 'string' ? value.trim() : '';
}
function required(body, fields) {
  return fields.filter(field => !cleanString(body[field]));
}
function asNumber(value) {
  const number = Number(value);
  return Number.isFinite(number) ? number : NaN;
}
function getBookStatus(book, loans) {
  const active = loans.some(loan => loan.bookId === book.id && loan.status === 'Issued');
  return active ? 'Issued' : 'Available';
}

// Dashboard summary
app.get('/api/dashboard', (req, res) => {
  const books = readData(booksFile);
  const members = readData(membersFile);
  const loans = readData(loansFile);
  const activeLoans = loans.filter(loan => loan.status === 'Issued');
  const overdue = activeLoans.filter(loan => new Date(loan.dueDate + 'T23:59:59') < new Date());
  res.json({
    totalBooks: books.reduce((sum, book) => sum + (Number(book.quantity) || 0), 0),
    bookTitles: books.length,
    totalMembers: members.length,
    issuedBooks: activeLoans.length,
    overdueBooks: overdue.length
  });
});

// Books CRUD
app.get('/api/books', (req, res) => {
  const books = readData(booksFile);
  const loans = readData(loansFile);
  const q = cleanString(req.query.q).toLowerCase();
  const filtered = books.map(book => ({
    ...book,
    available: Math.max(0, Number(book.quantity) - loans.filter(loan => loan.bookId === book.id && loan.status === 'Issued').length),
    status: getBookStatus(book, loans)
  })).filter(book => !q || [book.title, book.author, book.isbn, book.category].some(value => String(value || '').toLowerCase().includes(q)));
  res.json(filtered);
});

app.post('/api/books', (req, res) => {
  const body = req.body || {};
  const missing = required(body, ['title', 'author', 'isbn', 'category']);
  if (missing.length) return res.status(400).json({ error: `Please provide: ${missing.join(', ')}.` });
  const quantity = asNumber(body.quantity);
  if (!Number.isInteger(quantity) || quantity < 1) return res.status(400).json({ error: 'Quantity must be a whole number greater than 0.' });
  const books = readData(booksFile);
  if (books.some(book => book.isbn.toLowerCase() === cleanString(body.isbn).toLowerCase())) {
    return res.status(409).json({ error: 'A book with this ISBN already exists.' });
  }
  const book = {
    id: nextId(books),
    title: cleanString(body.title),
    author: cleanString(body.author),
    isbn: cleanString(body.isbn),
    category: cleanString(body.category),
    quantity,
    shelf: cleanString(body.shelf) || 'Not assigned',
    addedAt: new Date().toISOString()
  };
  books.push(book);
  writeData(booksFile, books);
  res.status(201).json(book);
});

app.put('/api/books/:id', (req, res) => {
  const id = Number(req.params.id);
  const books = readData(booksFile);
  const index = books.findIndex(book => book.id === id);
  if (index < 0) return res.status(404).json({ error: 'Book not found.' });
  const body = req.body || {};
  const missing = required(body, ['title', 'author', 'isbn', 'category']);
  if (missing.length) return res.status(400).json({ error: `Please provide: ${missing.join(', ')}.` });
  const quantity = asNumber(body.quantity);
  if (!Number.isInteger(quantity) || quantity < 1) return res.status(400).json({ error: 'Quantity must be a whole number greater than 0.' });
  if (books.some(book => book.id !== id && book.isbn.toLowerCase() === cleanString(body.isbn).toLowerCase())) {
    return res.status(409).json({ error: 'Another book already uses this ISBN.' });
  }
  const activeLoans = readData(loansFile).filter(loan => loan.bookId === id && loan.status === 'Issued').length;
  if (quantity < activeLoans) return res.status(400).json({ error: `Quantity cannot be lower than the ${activeLoans} currently issued copy/copies.` });
  books[index] = { ...books[index], title: cleanString(body.title), author: cleanString(body.author), isbn: cleanString(body.isbn), category: cleanString(body.category), quantity, shelf: cleanString(body.shelf) || 'Not assigned', updatedAt: new Date().toISOString() };
  writeData(booksFile, books);
  res.json(books[index]);
});

app.delete('/api/books/:id', (req, res) => {
  const id = Number(req.params.id);
  const books = readData(booksFile);
  const book = books.find(item => item.id === id);
  if (!book) return res.status(404).json({ error: 'Book not found.' });
  if (readData(loansFile).some(loan => loan.bookId === id && loan.status === 'Issued')) {
    return res.status(409).json({ error: 'This book has an active issue record. Return it before deleting the book.' });
  }
  writeData(booksFile, books.filter(item => item.id !== id));
  res.json({ message: 'Book deleted successfully.' });
});

// Members CRUD
app.get('/api/members', (req, res) => {
  const q = cleanString(req.query.q).toLowerCase();
  res.json(readData(membersFile).filter(member => !q || [member.name, member.email, member.phone, member.memberCode].some(value => String(value || '').toLowerCase().includes(q))));
});

app.post('/api/members', (req, res) => {
  const body = req.body || {};
  const missing = required(body, ['name', 'email', 'phone']);
  if (missing.length) return res.status(400).json({ error: `Please provide: ${missing.join(', ')}.` });
  const members = readData(membersFile);
  const email = cleanString(body.email).toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: 'Please enter a valid email address.' });
  if (members.some(member => member.email.toLowerCase() === email)) return res.status(409).json({ error: 'A member with this email already exists.' });
  const member = { id: nextId(members), memberCode: `LIB-${String(nextId(members)).padStart(4, '0')}`, name: cleanString(body.name), email, phone: cleanString(body.phone), course: cleanString(body.course) || 'Not specified', joinedAt: new Date().toISOString() };
  members.push(member);
  writeData(membersFile, members);
  res.status(201).json(member);
});

app.put('/api/members/:id', (req, res) => {
  const id = Number(req.params.id);
  const members = readData(membersFile);
  const index = members.findIndex(member => member.id === id);
  if (index < 0) return res.status(404).json({ error: 'Member not found.' });
  const body = req.body || {};
  const missing = required(body, ['name', 'email', 'phone']);
  if (missing.length) return res.status(400).json({ error: `Please provide: ${missing.join(', ')}.` });
  const email = cleanString(body.email).toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: 'Please enter a valid email address.' });
  if (members.some(member => member.id !== id && member.email.toLowerCase() === email)) return res.status(409).json({ error: 'Another member already uses this email.' });
  members[index] = { ...members[index], name: cleanString(body.name), email, phone: cleanString(body.phone), course: cleanString(body.course) || 'Not specified', updatedAt: new Date().toISOString() };
  writeData(membersFile, members);
  res.json(members[index]);
});

app.delete('/api/members/:id', (req, res) => {
  const id = Number(req.params.id);
  const members = readData(membersFile);
  if (!members.some(member => member.id === id)) return res.status(404).json({ error: 'Member not found.' });
  if (readData(loansFile).some(loan => loan.memberId === id && loan.status === 'Issued')) return res.status(409).json({ error: 'This member has a book currently issued. Return it before deleting the member.' });
  writeData(membersFile, members.filter(member => member.id !== id));
  res.json({ message: 'Member deleted successfully.' });
});

// Issue/return
app.get('/api/loans', (req, res) => {
  const q = cleanString(req.query.q).toLowerCase();
  const books = readData(booksFile);
  const members = readData(membersFile);
  const loans = readData(loansFile).map(loan => ({
    ...loan,
    bookTitle: books.find(book => book.id === loan.bookId)?.title || 'Deleted book',
    memberName: members.find(member => member.id === loan.memberId)?.name || 'Deleted member'
  })).filter(loan => !q || [loan.bookTitle, loan.memberName, loan.status].some(value => String(value).toLowerCase().includes(q)));
  res.json(loans.sort((a, b) => b.id - a.id));
});

app.post('/api/loans', (req, res) => {
  const bookId = Number(req.body?.bookId);
  const memberId = Number(req.body?.memberId);
  const dueDate = cleanString(req.body?.dueDate);
  if (!bookId || !memberId || !dueDate) return res.status(400).json({ error: 'Book, member and due date are required.' });
  if (!/^\d{4}-\d{2}-\d{2}$/.test(dueDate) || Number.isNaN(new Date(dueDate).getTime())) return res.status(400).json({ error: 'Please provide a valid due date.' });
  const books = readData(booksFile);
  const members = readData(membersFile);
  const loans = readData(loansFile);
  const book = books.find(item => item.id === bookId);
  if (!book) return res.status(404).json({ error: 'Selected book not found.' });
  if (!members.some(item => item.id === memberId)) return res.status(404).json({ error: 'Selected member not found.' });
  const activeCount = loans.filter(loan => loan.bookId === bookId && loan.status === 'Issued').length;
  if (activeCount >= book.quantity) return res.status(409).json({ error: 'No copies are currently available for this book.' });
  const loan = { id: nextId(loans), bookId, memberId, issueDate: new Date().toISOString().slice(0, 10), dueDate, returnDate: null, status: 'Issued' };
  loans.push(loan);
  writeData(loansFile, loans);
  res.status(201).json(loan);
});

app.patch('/api/loans/:id/return', (req, res) => {
  const id = Number(req.params.id);
  const loans = readData(loansFile);
  const index = loans.findIndex(loan => loan.id === id);
  if (index < 0) return res.status(404).json({ error: 'Issue record not found.' });
  if (loans[index].status === 'Returned') return res.status(409).json({ error: 'This book has already been returned.' });
  loans[index] = { ...loans[index], status: 'Returned', returnDate: new Date().toISOString().slice(0, 10) };
  writeData(loansFile, loans);
  res.json(loans[index]);
});

app.get('/api/health', (req, res) => res.json({ status: 'ok', storage: 'JSON files', database: false }));

app.use('/api', (req, res) => res.status(404).json({ error: 'API endpoint not found.' }));
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'Unexpected server error.' });
});

app.listen(PORT, () => {
  console.log(`Library Management System running at http://localhost:${PORT}`);
});
