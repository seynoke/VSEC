const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];
const state = { books: [], members: [], loans: [], currentView: 'dashboard', modalType: null, editId: null, toastTimer: null };
const API = '/api';

async function api(url, options = {}) {
  const response = await fetch(`${API}${url}`, {
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    ...options
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || 'Something went wrong.');
  return data;
}
function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
}
function initials(value) {
  return String(value || '?').split(/\s+/).filter(Boolean).slice(0, 2).map(part => part[0].toUpperCase()).join('');
}
function dateText(value) {
  if (!value) return '—';
  const date = new Date(`${value}T00:00:00`);
  return Number.isNaN(date.getTime()) ? value : date.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
}
function isOverdue(loan) {
  return loan.status === 'Issued' && new Date(`${loan.dueDate}T23:59:59`) < new Date();
}
function showToast(message, error = false) {
  const toast = $('#toast');
  toast.textContent = message;
  toast.className = `toast show${error ? ' error' : ''}`;
  clearTimeout(state.toastTimer);
  state.toastTimer = setTimeout(() => toast.className = 'toast', 3000);
}
function showView(view) {
  state.currentView = view;
  $$('.view').forEach(section => section.classList.toggle('active-view', section.id === `view-${view}`));
  $$('.nav-item').forEach(button => button.classList.toggle('active', button.dataset.view === view));
  $('#pageCrumb').textContent = ({dashboard:'Dashboard',books:'Book collection',members:'Members',loans:'Issue & returns'})[view] || 'Dashboard';
  $('#sidebar').classList.remove('open');
  if (view === 'books') renderBooks();
  if (view === 'members') renderMembers();
  if (view === 'loans') renderLoans();
}
async function refreshAll() {
  try {
    const [books, members, loans, dashboard] = await Promise.all([
      api('/books'), api('/members'), api('/loans'), api('/dashboard')
    ]);
    state.books = books;
    state.members = members;
    state.loans = loans;
    renderDashboard(dashboard);
    renderBooks();
    renderMembers();
    renderLoans();
  } catch (error) {
    showToast(error.message || 'Could not load library data.', true);
  }
}
function renderDashboard(dashboard) {
  $('#statTotalBooks').textContent = dashboard.totalBooks;
  $('#statMembers').textContent = dashboard.totalMembers;
  $('#statIssued').textContent = dashboard.issuedBooks;
  $('#statOverdue').textContent = dashboard.overdueBooks;
  $('#navBookCount').textContent = dashboard.bookTitles;
  const recent = [...state.books].sort((a,b) => b.id-a.id).slice(0,5);
  $('#recentBooksBody').innerHTML = recent.length ? recent.map(book => `
    <tr><td><div class="book-cell"><div class="book-cover cover-${book.id%5}">${escapeHtml(initials(book.title))}</div><div><strong>${escapeHtml(book.title)}</strong><small>${escapeHtml(book.author)}</small></div></div></td>
    <td><span class="category-tag">${escapeHtml(book.category)}</span></td>
    <td><span class="availability ${book.available > 0 ? 'available' : 'issued'}">${book.available} of ${book.quantity} available</span></td></tr>`).join('') : '<tr><td colspan="3" class="empty-state">No books yet. Add your first book to get started.</td></tr>';
  const recentLoans = [...state.loans].sort((a,b) => b.id-a.id).slice(0,5);
  $('#recentLoansBody').innerHTML = recentLoans.length ? recentLoans.map(loan => `
    <tr><td>${escapeHtml(loan.bookTitle)}</td><td>${escapeHtml(loan.memberName)}</td><td>${dateText(loan.issueDate)}</td><td>${dateText(loan.dueDate)}</td><td>${statusPill(loan)}</td></tr>`).join('') : '<tr><td colspan="5" class="empty-state">No issue activity yet.</td></tr>';
}
function renderBooks() {
  const q = ($('#bookSearch')?.value || '').trim().toLowerCase();
  const books = state.books.filter(book => !q || [book.title,book.author,book.isbn,book.category,book.shelf].some(value => String(value || '').toLowerCase().includes(q)));
  $('#bookResultCount').textContent = `${books.length} ${books.length === 1 ? 'book' : 'books'}`;
  $('#booksBody').innerHTML = books.length ? books.map(book => `
    <tr><td><div class="book-cell"><div class="book-cover cover-${book.id%5}">${escapeHtml(initials(book.title))}</div><div><strong>${escapeHtml(book.title)}</strong><small>by ${escapeHtml(book.author)}</small></div></div></td>
    <td>${escapeHtml(book.isbn)}</td><td><span class="category-tag">${escapeHtml(book.category)}</span></td>
    <td><strong>${book.available}</strong><span class="muted"> / ${book.quantity}</span></td><td>${escapeHtml(book.shelf || '—')}</td>
    <td><div class="action-buttons"><button class="small-btn" data-edit-book="${book.id}">Edit</button><button class="small-btn danger" data-delete-book="${book.id}">Delete</button></div></td></tr>`).join('') : '<tr><td colspan="6" class="empty-state">No matching books found.</td></tr>';
}
function renderMembers() {
  const q = ($('#memberSearch')?.value || '').trim().toLowerCase();
  const members = state.members.filter(member => !q || [member.name,member.email,member.phone,member.memberCode,member.course].some(value => String(value || '').toLowerCase().includes(q)));
  $('#memberResultCount').textContent = `${members.length} ${members.length === 1 ? 'member' : 'members'}`;
  $('#membersBody').innerHTML = members.length ? members.map(member => `
    <tr><td><div class="member-cell"><div class="member-avatar">${escapeHtml(initials(member.name))}</div><div><strong>${escapeHtml(member.name)}</strong><small>Joined ${dateText((member.joinedAt || '').slice(0,10))}</small></div></div></td>
    <td><span class="category-tag">${escapeHtml(member.memberCode)}</span></td><td>${escapeHtml(member.email)}</td><td>${escapeHtml(member.phone)}</td><td>${escapeHtml(member.course)}</td>
    <td><div class="action-buttons"><button class="small-btn" data-edit-member="${member.id}">Edit</button><button class="small-btn danger" data-delete-member="${member.id}">Delete</button></div></td></tr>`).join('') : '<tr><td colspan="6" class="empty-state">No members found. Add a reader to get started.</td></tr>';
}
function statusPill(loan) {
  if (loan.status === 'Returned') return '<span class="status-pill returned">Returned</span>';
  if (isOverdue(loan)) return '<span class="status-pill overdue">Overdue</span>';
  return '<span class="status-pill issued">Issued</span>';
}
function renderLoans() {
  const q = ($('#loanSearch')?.value || '').trim().toLowerCase();
  const loans = state.loans.filter(loan => !q || [loan.bookTitle,loan.memberName,loan.status,loan.dueDate].some(value => String(value || '').toLowerCase().includes(q)));
  $('#loanResultCount').textContent = `${loans.length} ${loans.length === 1 ? 'record' : 'records'}`;
  $('#loansBody').innerHTML = loans.length ? loans.map(loan => `
    <tr><td><strong>${escapeHtml(loan.bookTitle)}</strong></td><td>${escapeHtml(loan.memberName)}</td><td>${dateText(loan.issueDate)}</td><td>${dateText(loan.dueDate)}</td><td>${statusPill(loan)}</td>
    <td>${loan.status === 'Issued' ? `<button class="small-btn" data-return-loan="${loan.id}">Mark returned</button>` : `<span class="muted">${dateText(loan.returnDate)}</span>`}</td></tr>`).join('') : '<tr><td colspan="6" class="empty-state">No issue records found.</td></tr>';
}

function field(name, label, type = 'text', value = '', options = {}) {
  const full = options.full ? ' full' : '';
  const required = options.required === false ? '' : ' required';
  let control;
  if (type === 'select') {
    control = `<select name="${name}"${required}>${(options.options || []).map(option => `<option value="${escapeHtml(option.value)}" ${String(value)===String(option.value)?'selected':''}>${escapeHtml(option.label)}</option>`).join('')}</select>`;
  } else {
    control = `<input name="${name}" type="${type}" value="${escapeHtml(value)}" placeholder="${escapeHtml(options.placeholder || '')}"${type==='number'?' min="1"':''}${required}>`;
  }
  return `<div class="field${full ? ' full' : ''}"><label for="field-${name}">${label}${required ? ' *' : ''}</label>${control.replace(`name="${name}"`, `id="field-${name}" name="${name}"`)}</div>`;
}
function openModal(type, record = null) {
  state.modalType = type;
  state.editId = record?.id ?? null;
  $('#formError').textContent = '';
  $('#modalBackdrop').classList.add('open');
  $('#modalBackdrop').setAttribute('aria-hidden','false');
  const isEdit = Boolean(record);
  let title = '', description = '', fields = '';
  if (type === 'book') {
    title = isEdit ? 'Edit book details' : 'Add a new book';
    description = 'Keep your library collection accurate and organized.';
    fields = field('title','Book title','text',record?.title || '',{full:true,placeholder:'e.g. The Alchemist'}) +
      field('author','Author','text',record?.author || '',{placeholder:'Author name'}) +
      field('isbn','ISBN','text',record?.isbn || '',{placeholder:'ISBN / book code'}) +
      field('category','Category','select',record?.category || 'Fiction',{options:['Fiction','Non-fiction','Science','Technology','History','Biography','Education','Reference','Other'].map(v=>({value:v,label:v}))}) +
      field('quantity','Total copies','number',record?.quantity ?? 1,{placeholder:'1'}) +
      field('shelf','Shelf location','text',record?.shelf || '',{placeholder:'e.g. A-03'});
  } else if (type === 'member') {
    title = isEdit ? 'Edit member details' : 'Register a member';
    description = 'Add a reader and their contact information.';
    fields = field('name','Full name','text',record?.name || '',{full:true,placeholder:'Reader full name'}) +
      field('email','Email address','email',record?.email || '',{full:true,placeholder:'reader@example.com'}) +
      field('phone','Phone number','tel',record?.phone || '',{placeholder:'Contact number'}) +
      field('course','Course / department','text',record?.course === 'Not specified' ? '' : record?.course || '',{placeholder:'e.g. IT Engineering',required:false});
  } else if (type === 'loan') {
    title = 'Issue a book';
    description = 'Select an available book and a registered member.';
    const availableBooks = state.books.filter(book => book.available > 0);
    fields = field('bookId','Book to issue','select','',{full:true,options:[{value:'',label:'Choose a book'},...availableBooks.map(book=>({value:book.id,label:`${book.title} — ${book.available} available`}))]}) +
      field('memberId','Library member','select','',{full:true,options:[{value:'',label:'Choose a member'},...state.members.map(member=>({value:member.id,label:`${member.name} (${member.memberCode})`}))]}) +
      field('dueDate','Due date','date',new Date(Date.now()+14*86400000).toISOString().slice(0,10),{full:true});
    if (!availableBooks.length) fields = '<div class="field full"><p class="muted">There are no available book copies. Add a book or return an issued copy first.</p></div>' + fields;
    if (!state.members.length) fields = '<div class="field full"><p class="muted">Register a member before issuing a book.</p></div>' + fields;
  }
  $('#modalTitle').textContent = title;
  $('#modalDescription').textContent = description;
  $('#modalEyebrow').textContent = type === 'loan' ? 'CIRCULATION' : type === 'member' ? 'MEMBERSHIP' : 'COLLECTION';
  $('#formFields').innerHTML = fields;
  $('#saveRecordBtn').textContent = type === 'loan' ? 'Issue book' : isEdit ? 'Save changes' : 'Save record';
  $('#saveRecordBtn').disabled = type === 'loan' && (!state.books.some(book=>book.available>0) || !state.members.length);
  setTimeout(() => $('#formFields input, #formFields select')?.focus(), 50);
}
function closeModal() {
  $('#modalBackdrop').classList.remove('open');
  $('#modalBackdrop').setAttribute('aria-hidden','true');
  $('#recordForm').reset();
  state.modalType = null;
  state.editId = null;
}
async function submitModal(event) {
  event.preventDefault();
  $('#formError').textContent = '';
  const data = Object.fromEntries(new FormData(event.currentTarget).entries());
  try {
    if (state.modalType === 'book') {
      data.quantity = Number(data.quantity);
      await api(state.editId ? `/books/${state.editId}` : '/books', { method: state.editId ? 'PUT' : 'POST', body: JSON.stringify(data) });
      showToast(state.editId ? 'Book details updated.' : 'Book added to collection.');
    } else if (state.modalType === 'member') {
      await api(state.editId ? `/members/${state.editId}` : '/members', { method: state.editId ? 'PUT' : 'POST', body: JSON.stringify(data) });
      showToast(state.editId ? 'Member details updated.' : 'Member registered successfully.');
    } else if (state.modalType === 'loan') {
      data.bookId = Number(data.bookId);
      data.memberId = Number(data.memberId);
      await api('/loans', { method: 'POST', body: JSON.stringify(data) });
      showToast('Book issued successfully.');
    }
    const view = state.modalType === 'loan' ? 'loans' : state.modalType === 'member' ? 'members' : state.currentView;
    closeModal();
    await refreshAll();
    showView(view);
  } catch (error) {
    $('#formError').textContent = error.message;
  }
}
async function deleteRecord(type, id) {
  const label = type === 'books' ? 'book' : 'member';
  if (!confirm(`Delete this ${label}? This action cannot be undone.`)) return;
  try {
    await api(`/${type}/${id}`, { method: 'DELETE' });
    showToast(`${label[0].toUpperCase()+label.slice(1)} deleted.`);
    await refreshAll();
  } catch (error) { showToast(error.message, true); }
}
async function returnLoan(id) {
  if (!confirm('Mark this book as returned?')) return;
  try {
    await api(`/loans/${id}/return`, { method: 'PATCH', body: JSON.stringify({}) });
    showToast('Book marked as returned.');
    await refreshAll();
  } catch (error) { showToast(error.message, true); }
}

$$('.nav-item').forEach(button => button.addEventListener('click', () => showView(button.dataset.view)));
$$('[data-go]').forEach(button => button.addEventListener('click', () => showView(button.dataset.go)));
$('#quickAddBook').addEventListener('click', () => openModal('book'));
$('#addBookBtn').addEventListener('click', () => openModal('book'));
$('#addMemberBtn').addEventListener('click', () => openModal('member'));
$('#issueBookBtn').addEventListener('click', () => openModal('loan'));
$('#quickIssue').addEventListener('click', () => openModal('loan'));
$('#quickMember').addEventListener('click', () => openModal('member'));
$('#closeModal').addEventListener('click', closeModal);
$('#cancelModal').addEventListener('click', closeModal);
$('#modalBackdrop').addEventListener('click', event => { if (event.target === $('#modalBackdrop')) closeModal(); });
$('#recordForm').addEventListener('submit', submitModal);
$('#bookSearch').addEventListener('input', renderBooks);
$('#memberSearch').addEventListener('input', renderMembers);
$('#loanSearch').addEventListener('input', renderLoans);
$('#mobileMenu').addEventListener('click', () => $('#sidebar').classList.toggle('open'));

document.addEventListener('click', event => {
  const editBook = event.target.closest('[data-edit-book]');
  const deleteBook = event.target.closest('[data-delete-book]');
  const editMember = event.target.closest('[data-edit-member]');
  const deleteMember = event.target.closest('[data-delete-member]');
  const returnButton = event.target.closest('[data-return-loan]');
  if (editBook) openModal('book', state.books.find(book => book.id === Number(editBook.dataset.editBook)));
  if (deleteBook) deleteRecord('books', Number(deleteBook.dataset.deleteBook));
  if (editMember) openModal('member', state.members.find(member => member.id === Number(editMember.dataset.editMember)));
  if (deleteMember) deleteRecord('members', Number(deleteMember.dataset.deleteMember));
  if (returnButton) returnLoan(Number(returnButton.dataset.returnLoan));
});
document.addEventListener('keydown', event => { if (event.key === 'Escape' && $('#modalBackdrop').classList.contains('open')) closeModal(); });

refreshAll();
